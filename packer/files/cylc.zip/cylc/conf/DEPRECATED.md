The `conf/` directory was deprecated at cylc-7.7.0, symlinks to the syntax
file (which now reside in `etc/syntax`) will be removed at cylc-8.0.0.
